/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testExamen;

import examen.DieselGasolina;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 *  @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */
public class TestDieselGasolina {
    
    // instanciamos un objeto vacio y asignamos los valores en los atributos en cada test con los métodos set
    DieselGasolina object = new DieselGasolina();
    
    
    public TestDieselGasolina() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

   
     @Test
    public void testPrecioVentaDiesel(){
        object.setPrecioCompraD(1.07);
        double ResEsp = 1.712;
        // como estamos trabajando con precios de 2 cifras decimales tenemos que ajustar el delta en 0.01
        assertEquals(ResEsp, object.precioDieselVenta(), 0.01);
    }
    
     @Test
    public void testPrecioVentaGasolina(){
        object.setPrecioCompraG(0.93);
        double ResEsp = 1.674;
        // como estamos trabajando con precios de 2 cifras decimales tenemos que ajustar el delta en 0.01
        assertEquals(ResEsp, object.precioGasolinalVenta(), 0.01);
    }
    
    @Test 
    public void testReservaDiesel(){
        object.setLitrosD(510);
        // usamos asserFalse pq si pasamos 510 coo valor para el test el metodo reservaDiesel() debe devolver falso
        assertFalse(object.reservaDiesel());
    }
    @Test 
    public void testResevaGasolina(){
        object.setLitrosG(510);
        assertFalse(object.reservaGasolina());
    }
}
