package testExamen;



import static java.lang.Math.PI;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */

@RunWith (value = Parameterized.class)

public class TestCalculadoraWeb {
    
    Double radio ;  // atributo de la clase que se usa en los métodos y que reciirá el valor de los vectores de parámetros
    
    WebDriver driver ; // atributo para declarar el driver navegador
    
 // Constructor que en un test parametrizado instanciará tantos test como vectores de parámetros se utilizen
    public TestCalculadoraWeb(double radio){
       this.radio = radio;
       
   }
   // parámetros con los distintos vectores de valores de cada test
    @Parameters
public static Collection<Object[]> data() {
Object[][] data = new Object[][] { {12.567}, {84.667}, {90.247},{59.333},{10.546} } ;
return Arrays.asList(data);
}
    
   // método que se ejecuta al principio de la clase, debe ser un método estático
   // en este método definimos la propiedad del sistema para identificar la dirección del controlador.exe que conecta el programa java con el navegador
    @BeforeClass
    public static void setUpClass() {
        
        System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
    }
    
    @AfterClass
    public static void tearDownClass() {
    
    }
    // método que define sentencias  que se ejecutarán antes de cada test
    // antes de cada test instanciamos el driver para abrir el navegador, cargamos la url, maximizamos y hacemos click en el botóin aceptar cookies
    // tamnbien se define un tiempo de espera implicito en la localización de elementos de la web
    @Before
    public void setUp() {
        
        driver = new ChromeDriver();
        driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        driver.get("https://web2.0calc.es/");
        driver.findElement(By.xpath("/html/body/div[8]/div[2]/div[1]/div[2]/div[2]/button[1]")).click();
    }
    
    @After
    public void tearDown() {
        
       driver.quit();
    }
    
    
    // test que se evalua donde definimos los elementos a identificar y los eventos cobre los mismos para realizar el cálculo que se pide
    // debe contener un assert que impemente la lógica condicional y devuelva si pasa o no el test
    @Test
     public void TestAreaCirculo() throws InterruptedException{
         
         
       Thread.sleep(1000);
         driver.findElement(By.cssSelector("#input")).sendKeys(String.valueOf(radio));
         Thread.sleep(1000);
        driver.findElement(By.cssSelector("#BtnPow2")).click();
         Thread.sleep(1000);
         driver.findElement(By.cssSelector("#BtnCalc")).click();
         Thread.sleep(1000);
         driver.findElement(By.cssSelector("#BtnMult")).click();
         Thread.sleep(1000);
         driver.findElement(By.cssSelector("#BtnPi")).click();
         Thread.sleep(1000);
         driver.findElement(By.cssSelector("#BtnCalc")).click();
         Thread.sleep(3000);
        
        
        
        Double resultado = Double.parseDouble(driver.findElement(By.cssSelector("#input")).getAttribute("value"));
        Double resEsperado = Math.pow(radio,2)*Math.PI;
       
        assertEquals(resEsperado, resultado , 0.000001);
        
        
         
     }
   
}
