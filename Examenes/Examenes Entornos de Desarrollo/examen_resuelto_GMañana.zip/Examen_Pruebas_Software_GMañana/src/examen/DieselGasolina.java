/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

/**
 *
 *  @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */
public class DieselGasolina {
    
    // atributos de la clase que deben ser privados segun convenciones de java y acceder a ellos con los métodos sets y gets
    private double litrosG;
    private double litrosD;
    private double precioCompraG;
    private double precioCompraD;

    // constrructores. Como no nos dicen nada sobre los constructores defiunimos uno con todos los argumentos de los atributos y otro vacio.
    
    public DieselGasolina(double litrosG, double litrosD, double precioCompraG, double precioCompraD) {
        this.litrosG = litrosG;
        this.litrosD = litrosD;
        this.precioCompraG = precioCompraG;
        this.precioCompraD = precioCompraD;
    }

    public DieselGasolina() {
    }
    
    // Gets y Sets para acceder a los atributos. Estos métodos se definen por defecto para acceder a los atributos private

    public double getLitrosG() {
        return litrosG;
    }

    public double getLitrosD() {
        return litrosD;
    }

    public double getPrecioCompraG() {
        return precioCompraG;
    }

    public double getPrecioCompraD() {
        return precioCompraD;
    }

    public void setLitrosG(double litrosG) {
        this.litrosG = litrosG;
    }

    public void setLitrosD(double litrosD) {
        this.litrosD = litrosD;
    }

    public void setPrecioCompraG(double precioCompraG) {
        this.precioCompraG = precioCompraG;
    }

    public void setPrecioCompraD(double precioCompraD) {
        this.precioCompraD = precioCompraD;
    }
    
    
    // métodos 
    
    public double precioDieselVenta(){
         return this.precioCompraD + this.precioCompraD*0.1 + this.precioCompraD*0.5;
    }
    
     public double precioGasolinalVenta(){
         return this.precioCompraG + this.precioCompraG*0.1 + this.precioCompraG*0.7;
    }
    
     
     public boolean reservaDiesel(){
         if (this.litrosD<500){
             return true;
         }else{ return false;}
     }
    
     public boolean reservaGasolina(){
         if (this.litrosG<500){
             return true;
         }else{ return false;}
     }
    
    
    
    
}
