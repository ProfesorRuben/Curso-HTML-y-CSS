/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package testExamen;


import examen.Examen2e;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */
public class TestEjercicio1 {
     
// instanciamos un objeto vacio y asignamos los valores en los atributos en cada test con los métodos set
    Examen2e object = new Examen2e();
    
    public TestEjercicio1() {
    }
    
   /*
    // estos métodos en este caso no lo utilizamnos por lo que se pudeden comentar
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    */
    
    @Test
     public void testNotaExamen() {
     // definimos la nota y la ponderación de cada ejercicio usaremos 6.2 - 8.5 como notas y 0,35 - 0,65 como ponderaciones
      object.setNotaE1(6.2);
      object.setNotaE2(8.5);
      object.setPonderacionE1(0.35);
      object.setPonderacionE2(0.65);
      
      double resEsperado = 6.2*0.35+8.5*0.65;
      
      // en el assert definimos 0.1 como delta ya que estamos trabajando con numeros de 2 decimales
      assertEquals(resEsperado, object.notaExamen(), 0.01);
         
     }
     
    @Test
    public void testSuperado() {
       // definimos la nota y la ponderación de cada ejercicio de nuevo y también  el valor de la nota de superación para el test
      object.setNotaE1(5.8);
      object.setNotaE1(7.5);
      object.setPonderacionE1(0.35);
      object.setPonderacionE1(0.65);
      
        // con este contexto debe dar true el método superado asi que definimos el asserTrue
      assertTrue(object.superado());
     }
     
}
