package testExamen;




import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */

@RunWith (value = Parameterized.class)

public class TestCalculadorasWeb {
    
    // atributos de la clase Test
    // se diseñan los test en función de estos atributos al ser parametrizado
    int nTriangulo ;
    double base ;
    double altura ;
    
    // atributo para declarar el driver navegador
    WebDriver driver ; 
    
    // Constructor que en un test parametrizado instanciará tantos test como vectores de parámetros se utilizen
   public TestCalculadorasWeb(int nTriangulo, double base, double altura){
       this.base = base;
       this.altura = altura;
       this.nTriangulo = nTriangulo;
     }
   
    // parámetros con los distintos vectores de valores de cada test
    @Parameters
    public static Collection<Object[]> data() {
    Object[][] data = new Object[][] { {1, 12.567, 45.3333}, {2, 84.667, 56.656}, {3, 90.247, 23.67} } ;
    return Arrays.asList(data);
    }
    
    // método que se ejecuta al principio de la clase, debe ser un método estático
   // en este método definimos la propiedad del sistema para identificar la dirección del controlador.exe que conecta el programa java con el navegador
    @BeforeClass
    public static void setUpClass() {
        
        System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
    }
    
    @AfterClass
    public static void tearDownClass() {
    
    }
    
   
    // método que define sentencias  que se ejecutarán antes de cada test
    // en nuestro caso antes del test cada test instanciamos el driver para abrir el navegador, cargamos la url, maximizamos 
    
    @Before
    public void setUp() {
        
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);
        driver.manage().window().maximize();
    
    }
    
    // ceraremos el navegador al finalizar el test
    @After
    public void tearDown() {
        
      driver.quit();
    }
    
    // test que implementa un método donde definimos los elementos web a localizar  y los eventos sobre los mismos para realizar el cálculo que se pide a base de scritp de eventos sobre las webs de calculadoras
    // debe contener un assert que impemente la lógica condicional y devuelva si pasa o no el test
    @Test
     public void TestAreaCirculo() throws InterruptedException{
         
       driver.get("https://google.es");
       driver.findElement(By.cssSelector("#L2AGLb")).click();
       
       Thread.sleep(1000);
      
       driver.findElement(By.cssSelector("body > div.L3eUgb > div.o3j99.ikrT4e.om7nvf > form > div:nth-child(1) > div.A8SBwf > div.RNNXgb > div > div.a4bIc > input")).sendKeys("calculadora");
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("body > div.L3eUgb > div.o3j99.ikrT4e.om7nvf > form > div:nth-child(1) > div.A8SBwf > div.RNNXgb > div > div.a4bIc > input")).sendKeys(Keys.ENTER);
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.BRpYC > div.TIGsTb > div.fB3vD > div")).sendKeys(String.valueOf(base));
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.SKWP2e > div > table.ElumCf > tbody > tr:nth-child(3) > td:nth-child(4) > div > div")).click();
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.BRpYC > div.TIGsTb > div.fB3vD > div")).sendKeys(String.valueOf(altura));
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.SKWP2e > div > table.ElumCf > tbody > tr:nth-child(2) > td:nth-child(4) > div > div")).click();
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.BRpYC > div.TIGsTb > div.fB3vD > div")).sendKeys(String.valueOf(2));
       Thread.sleep(1000);
       driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.SKWP2e > div > table.ElumCf > tbody > tr:nth-child(5) > td:nth-child(3) > div > div")).click();
       Thread.sleep(3000);
       String resultado1 = driver.findElement(By.cssSelector("#rso > div:nth-child(1) > div > div > div.card-section > div > div > div.BRpYC > div.TIGsTb > div.fB3vD > div")).getText();
     
        
        driver.get("https://web2.0calc.es/");
        driver.findElement(By.xpath("/html/body/div[8]/div[2]/div[1]/div[2]/div[2]/button[1]")).click();
        
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("#input")).sendKeys(String.valueOf(base));
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("#BtnMult")).click();
        driver.findElement(By.cssSelector("#input")).sendKeys(String.valueOf(altura));
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("#BtnDiv")).click();
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("#input")).sendKeys("2");
        Thread.sleep(1000);
        driver.findElement(By.cssSelector("#BtnCalc")).click();
        Thread.sleep(3000);
        String resultado2 = driver.findElement(By.cssSelector("#input")).getAttribute("value");
        
        System.out.println("Test triángulo "+ nTriangulo);
        System.out.println(" El resltado de la calculadora de Web2.0Calc es: "+resultado2);
        System.out.println(" El resltado de la calculadora de Google es: "+resultado2);
        
      // assert que compara el resultado de la operación de cálculo del área de los triángulos cuya base y altura se le ha pasado por parámetros
      // definimos una tolerancia de error de una millonésima en la comparación
      assertEquals(Double.parseDouble(resultado1), Double.parseDouble(resultado2) , 0.000001);
         
     }
   
}
