/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen;

import java.util.Date;

/**
 *
 * @author profesor Jorge Martín IES Ruiz Gijon - Utrera
 */
public class Examen2e {
    
    //atributos de la clase definidos private por defecto
    private String nombre;
    private Date fecha;
    private String contenidos;
    private String alumno;
    private double ponderacionE1;
    private double ponderacionE2;
    private double notaE1;
    private double notaE2;
    private double notaSuperado;
    
    
    // constructores , por defecto creamos un con todos los atributos como parámetros y una sobrecarga vacío.

    public Examen2e(String nombre, Date fecha, String contenidos, String alumno, double ponderacionE1, double ponderacionE2, double notaE1, double notaE2, double notaSuperado) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.contenidos = contenidos;
        this.alumno = alumno;
        this.ponderacionE1 = ponderacionE1;
        this.ponderacionE2 = ponderacionE2;
        this.notaE1 = notaE1;
        this.notaE2 = notaE2;
        this.notaSuperado = notaSuperado;
    }

    public Examen2e() {
    }
    
    
    // métodos Gets y Sets para cceder a los atributos que se definen privados

    public String getNombre() {
        return nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getContenidos() {
        return contenidos;
    }

    public String getAlumno() {
        return alumno;
    }

    public double getPonderacionE1() {
        return ponderacionE1;
    }

    public double getPonderacionE2() {
        return ponderacionE2;
    }

    public double getNotaE1() {
        return notaE1;
    }

    public double getNotaE2() {
        return notaE2;
    }

    public double getNotaSuperado() {
        return notaSuperado;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setContenidos(String contenidos) {
        this.contenidos = contenidos;
    }

    public void setAlumno(String alumno) {
        this.alumno = alumno;
    }

    public void setPonderacionE1(double ponderacionE1) {
        this.ponderacionE1 = ponderacionE1;
    }

    public void setPonderacionE2(double ponderacionE2) {
        this.ponderacionE2 = ponderacionE2;
    }

    public void setNotaE1(double notaE1) {
        this.notaE1 = notaE1;
    }

    public void setNotaE2(double notaE2) {
        this.notaE2 = notaE2;
    }

    public void setNotaSuperado(double notaSuperado) {
        this.notaSuperado = notaSuperado;
    }
        
    
    // métodos funcionales de la clase 
    
    // notaExamen() devuelve la nota  que se calcula como nota1*ponderación1 + nota2*ponderación2
    // como ejemplo en este examen sería  nota Ejercicio1 * 0,35 + nota Ejercicio2 * 0,65    
    
    public double notaExamen(){     
        return notaE1*ponderacionE1+notaE2*ponderacionE2;
    }
    
    //  superado() devuelve true/ false segun se supere o no en relación a la nota de superación
    
    public boolean superado(){
        if ( notaExamen() >= this.notaSuperado){
            return true;
        }else{return false;}
        }
    
    
}
